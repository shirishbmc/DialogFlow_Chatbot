'use strict';
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
//const {WebhookClient} = require('dialogflow-fulfillment-improved');
const {google} = require('googleapis');
const vision = require('@google-cloud/vision');
const {Card, Suggestion} = require('dialogflow-fulfillment');
const axios = require('axios');

// initialise DB connection
const admin = require('firebase-admin');
admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  databaseURL: 'ws://agricultural-bot-njdmck-63206.firebaseio.com/',
});
process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging stateme


  var CVFNews = axios.create({
    method: 'get',
    baseURL: 'https://newsapi.org/v2/',
    headers: {'x-api-key': 'db491fe0ec86424485e0e77a41e7e11b'}
    });
 
//providing storage details:
const bucketName = 'agricultural-bot-njdmck.appspot.com';
//console.log("Parameters", agent.parameters);
const getNameHandler = "get_type";
const applyML = "explore_image";


process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements

 var WeatherNews = axios.create({
    method: 'get',
    baseURL: 'http://api.openweathermap.org/data/2.5/',
    headers: {'x-api-key': 'db7117cd435e1ae459f1254b80ce43ba'}
   });

const serviceAccount = {
  "type": "service_account",
  "project_id": "agricultural-bot-njdmck",
  "private_key_id": "469876871adb015e6dfc4c11ad914076b82ba44e",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDS79BWFhR23+7S\nk4U3eCAIU7MeU4HUya5FcplU9QOUZF35lXB1FZHKiTQ9rCUOfyJR0ks/4B2n6iZS\nUjXKUSZHdAjflex2yCa/L9IEv8MX0WRAyX11VZ1e5I56CPZjai67lXTsYU53kGCH\ntQXMmx8/h26u+uAVZURQ1RwyLdS/NvSEQNlGVQmhPALnz8YnvhkuHxr/nKA01CIw\nsCtduLtHMtbLfMF95TiTyvDwLnzs0FL3PBtc8E8idJmpXgG2X//RwQ23H+iWtw2h\nv0Xa3E4etffxu7uBFyGq75yUGVRmiRj3iOF6FsJ5D1chjP3e8kVx2Gml8c3DaCrc\nBdk5+quNAgMBAAECggEAFucWcA5oLOsN/3uoengWxEiwOVH4Vg4K17wEZXrP53AJ\nWxTMd83+fSbuDucuw9bud0NVy8rt9WIhRI1sDTpH5Xi2EO6ylMgRGu+ahkz65g5k\na/tknZWM53V5+cqY0/z+s3vcDOFY13cL4Bg517gdCbUPAb04EOKkqwEklVcwEw22\nG7EZ0DiqT39Vb/xWgZ4jk4i6A9KoxEdoKuHOmds03bL29cYlCNYiGvvkAZ8POtlL\n628c6E44BWPoBi0vF00UyqW7O2npRfae6JGusbzdepdNRutLyUgReGjY4e0jQMC/\nlpzIxTDSzTVAehWVopAKWVDgUDPhZ9shmrEl7qkJQQKBgQD7OnYNpKc65vISp3sJ\nNbGPve/n5/UVWsflRnFL0xMun1aSzs9ODU0VJ/ZIimIV8cCX7ff91DCTQgNP16nj\n3/N0iF93R8i2TFFn6FJXT7j1l/QUyFfo1BUYvnLQQx8CgIymQOiHDEWOPFc7bY/5\nVl2TeZDMAy1u9yhDx84ZTkUSQQKBgQDW8XG8P74aj3QdQ7GjhUuyGC8SZ+u7kPI8\n4vqwdd4/27Me5UewcE83TZMXRuIcR1uT1Nso171pIHTVyrd2NJq3dSVUzvqj3TGx\nX7b64uaS2txDTQ7bY2oIsNO093n551pqXzCkLof3ESQDXvAIAkrI2yhbQ+hxHpAG\nGNvQ8cyuTQKBgQCy6lqCst1J7Ik/UbkkwPF4bgs5vA7lq2Yq2XT8TBEgJefQ26n1\nazGXPIN/+9WIzUecq6PuSDxj0yJqrStXlvlZ53kdiKjfcxCSkHh7p9IQTaxNVLSO\nouN3YMKBoRune4cvK5CuBMZQWpbBQvDC4If57Bx7vlOP8ELjqpsTmJNGQQKBgHdH\nu9c9BHFW5JgM5fqZ0Tz/ALhVJVOMh3FUgMwGTRThBhECKft3B+7nxNXpBzesPdzX\nBdwvhTRex5eRDKizXpyqjNH4nszqxlXpiPDHlC8w94T9sV38WG6EOqg1oeIWCm33\nb1XdYKSyRWr9d3TqWLgILuge0lJcJI7NosbcOLsNAoGAN0qe2TQp/9NvxQjZzVgh\nZN732skUJmEfoTjI4u4O2Fl07F7fQwmFkBfh4V+zPncWWZUf03LMSfGhzn3AskOU\nB+2qHlZhK89VoYY2iVetd3RI+yeAEG5J6cOARGBA3UcXzZY4r+630FHTM9L4DgJL\njhEmlneDwtjU3NvB9qE7fUM=\n-----END PRIVATE KEY-----\n",
  "client_email": "agricultural-key@agricultural-bot-njdmck.iam.gserviceaccount.com",
  "client_id": "107300944979675882064",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/agricultural-key%40agricultural-bot-njdmck.iam.gserviceaccount.com"
}


exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request,response) =>{
  const agent = new WebhookClient({request, response});
 // const agent = new WebhookClient({request: request, response: response});
console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
  
function Currentweather(agent){
    response.setHeader('Content-Type','application/json');
    console.log('weather function', JSON.stringify(request.body.queryResult.parameters));
    const loc = agent.parameters.geocity;
  //  agent.add(`Below shown is temperature in Kelvin for Location #:${loc}`);
    return WeatherNews.get('/weather?q='+	encodeURIComponent(loc)  +'&units=metric')
        .then(function(response){
     console.log("Complete Weather Statistics :", JSON.stringify(response.data));
     var Currtemp = JSON.stringify(response.data.main.temp);
     var Mintemp = JSON.stringify(response.data.main.temp_min);
     var Maxtemp = JSON.stringify(response.data.main.temp_max);
     var pressure = JSON.stringify(response.data.main.pressure);
     var humidity = JSON.stringify(response.data.main.humidity);
     var Overcast = JSON.stringify(response.data.weather[0].description);
     var windSpeed = JSON.stringify(response.data.wind.speed);
     var sunrise = new Date(response.data.sys.sunrise*1000).toLocaleTimeString("en-US").slice(0,4);
     var sunset = new Date(response.data.sys.sunset*1000).toLocaleTimeString("en-US").slice(0,4); 
     
     console.log("Temperature is :", Currtemp );
  //   agent.add('The temperature for location  ' + loc + ' is: ' + Currtemp + '\nPressure is :'+ pressure + '\nHumidity is :' + humidity + '\nWind Speed is :' + windSpeed + '\nSituation is' + weatherMainDescription + 'with' + weatherDescription );
      agent.add(`\Below are the weather details for Location #:${loc}`);
      agent.add(`Current temperature    #:${Currtemp} degree Celsius`);
      agent.add(`Minimum temperature    #:${Mintemp} degree Celsius`);
      agent.add(`Maximum temperature    #:${Maxtemp} degree Celsius`);
      agent.add(`Pressure  #:${pressure}`);
      agent.add(`Overcast  #:${Overcast}`);
      agent.add(`windSpeed  #:${windSpeed}`);
      //agent.add(`SunRise time is #:${sunrise}`);
      //agent.add(`Sunset time  is #:${sunset}`);
     
   //  return agent.add('The temperature for location  ' + loc + ' is: ' + JSON.stringify(response.data) );
      })
        .catch(function(error){
            console.log(error);
        });
  }
 
//Forecast Function
    function Forecastweather(agent) {
    response.setHeader('Content-Type','application/json');
    const loc = agent.parameters.ForecastLocation;
    agent.add(`Below shown is Forecast for next 5 days in ${loc} at 12 p.m daily.`);
    return WeatherNews.get('/forecast?q='+	encodeURIComponent(loc)  +'&units=metric')
        .then(function(response){
     console.log("Weather forecast for next 5 days is :", JSON.stringify(response.data));
     
     var i = 0;
     for (i in JSON.stringify(response.data.list[i])) {
     
     //  if (i % 7 == 0) {
         //*********************************************
         var dt_text = JSON.stringify(response.data.list[i].dt_txt);
       	 var mySplitResult;
         mySplitResult = dt_text.split(" ");
         const midtime = String(mySplitResult[1]);
         
         var fixtime = "12:00:00\"";
         const time = String(fixtime);
        // agent.add(`*************date split result is #${mySplitResult[1]}`);
      //   agent.add(`******date split result is #${midtime}`);
       //  agent.add(`******Fix timeis #${time}`);
        //*********************************************
         if(midtime === time ){
           //=========================================
     	   var Currtemp = JSON.stringify(response.data.list[i].main.temp);
     	   var Mintemp = JSON.stringify(response.data.list[i].main.temp_min);
     	   var Maxtemp = JSON.stringify(response.data.list[i].main.temp_max);
     	   var pressure = JSON.stringify(response.data.list[i].main.pressure);
     	   var humidity = JSON.stringify(response.data.list[i].main.humidity);
     	   var Overcast = JSON.stringify(response.data.list[i].weather[0].description);
     	   var windSpeed = JSON.stringify(response.data.list[i].wind.speed);
     	   // var dt_text = JSON.stringify(response.data.list[i].dt_txt);
           agent.add(`\n###########################`);
      	   agent.add(`Forecast for Date   #:${dt_text}:`);
           agent.add(`#############################`);
      	   agent.add(`Current temperature    #:${Currtemp} degree Celsius`);
      	   agent.add(`Minimum temperature    #:${Mintemp} degree Celsius`);
      	   agent.add(`Maximum temperature    #:${Maxtemp} degree Celsius`);
      	   agent.add(`Overcast     #:${Overcast}`);
      	   agent.add(`Humidity    #:${humidity}`);
      	   agent.add(`Pressure    #:${pressure}`);
      	   agent.add(`windSpeed    #:${windSpeed}`);
           //===========================================
          }
       //}
    }
      
     // return agent.add('The weather forecast for next 5 days for location  ' + loc + ' is: ' + JSON.stringify(response.data));
        })
        .catch(function(error){
            console.log(error);
        });
  }
//==================================

  
 
  
function vegetation_schedule(agent)
  {
    let type = agent.parameters.type;

   agent.add(`fulfillment:you selected type: ${type}`);
      if(type.toLowerCase() == "herbs"){
 agent.add(`you selected ${type}. You can grow below herbs based on the schedule. Basil - May to October, Corriander - June to September, Parsley - May to December, Dill - June to October.Do you wish to know anything else?`);
 }
 else if(type.toLowerCase() == "salads"){
 agent.add(`you selected ${type}.You can grow below salads based on the schedule. Celery - July to November, Courgettes from July to September, Cucumbers from May to September, Lettuce from June to September.Do you wish to know anything else?`);
 }
 else if(type.toLowerCase() == "fruits"){
 agent.add(`you selected ${type}. You can grow below Fruits based on the schedule. Apples in October, blackberries in August, strawberries from June to October, Raspberries from July to October.Do you wish to know anything else?`);
 }
 else if(type.toLowerCase() == "vegetables"){
 agent.add(`you selected ${type}. You can grow below vegetables based on the schedule. Asparagus from May and June, Aubergines From May to August, Beetroot from August to Feb, Broad beans from June to August, Brocolli from June till November.Do you wish to know anything else ?`);
 }
 else{
 agent.add("Sorry , i dont Understand this ");
 }  
}
 
function visionAPIlabel(agent){
  var filename1 = agent.parameters.filename;
  console.log("filename is: ", filename1);
  console.log("bucketName is: ", bucketName);

    // call vision API to detect text
    return callVisionApi(agent, bucketName, filename1).then(result => {
       console.log(`#####Main functoin result is :`);
      agent.add(`####### Labels :######`);
      result.forEach(result22 =>
                     //console.log(result22.description)
                     agent.add(`${result22.description}`));
     //agent.add(`Inside visionApi Function : bucket name  #######:  ${bucketName}`);
    // agent.add(`Inside visionApi Function : filename  is #######:  ${filename1}`);
        }).catch((error)=> {
            agent.add(`error occurred at apply ml function`  + error);
        });
}
  
function news(agent) {
    response.setHeader('Content-Type','application/json');
    console.log('news function', JSON.stringify(request.body.queryResult.parameters));
    const word = agent.parameters.search;
    agent.add(`search word name #:${word}`);
    return CVFNews.get('top-headlines?q='+encodeURIComponent(word)+'&limit=1&tags=news')
        .then(function(response){
            const {title, source} = response.data.articles[0];
            //agent.add(`search word name #:${response.data.articles[0]}`);
            console.log('response', response.data);
            console.log('response', response.data.articles[0]);
            return agent.add('The last article about ' + word + ' was: ' + title + ' and was published by ' + source.name);
        })
        .catch(function(error){
            console.log(error);
        });
  }

 
 
function ReadfromDB(agent){  
const DBName = agent.parameters.DBName;
return admin.database().ref('vegetables').once('value').then((snapshot) => {
  var details = snapshot.child(DBName).val();
  if (snapshot.hasChild(`${DBName}`)){
   // agent.add(`${DBName} already exists in database.`);
    agent.add(`Below are the details:`);
        var time_to_grow = details.grow_time;
    var ph_val = details.ph_value;
    var ph_season = details.growing_season;
    agent.add(`***************************************`);
    agent.add(`Plant name #:${DBName}`);
    agent.add(`Time for growth for ${DBName} #:${time_to_grow}`);
    agent.add(`Soil ph value for ${DBName} #:${ph_val}`);
    agent.add(`Growing season for ${DBName} #:${ph_season}`);
    agent.add(`***************************************`);
  }
  else{
    agent.add(`I do not have information about this`);
    agent.add(`**Expert **Please provide information about ## ${DBName}:`);
  }
});
}
 
 
function WritetoDB(agent){  
  var DBName = request.body.queryResult.parameters.DBName;
  var grow_time = agent.parameters.grow_time11;
  var growing_season = agent.parameters.growing_season11;
  var ph_value = agent.parameters.ph_value11;
 

  agent.add(`Thanks Expert for the details, below data has been updated in Database:`);
  // agent.add(`***************************************`);
 // agent.add(`**plant name #:${DBName}:`);
 // agent.add(`Time for growth for ${DBName} #:${grow_time}:`);
 // agent.add(`Growing season for ${DBName} #:${growing_season}:`);
 // agent.add(`Soil ph value for ${DBName} :${ph_value}:`);
 // agent.add(`***************************************`);
    agent.add(`***************************************`);
    agent.add(`Plant name #:${DBName}`);
    agent.add(`Time for growth for ${DBName} #:${grow_time}`);
    agent.add(`Soil ph value for ${DBName} #:${ph_value}`);
    agent.add(`Growing season for ${DBName} #:${growing_season}`);
    agent.add(`***************************************`);
 
 return admin.database().ref('vegetables').child(`${DBName}`).set({
     grow_time: `${grow_time}`,
     growing_season: `${growing_season}`,
ph_value : `${ph_value}`,
   
});
 
}

 
   
let intentMap = new Map();
intentMap.set('get_type', vegetation_schedule);
intentMap.set('Image_label_int', visionAPIlabel);
intentMap.set('newsIntent', news);
intentMap.set('DBName_intent', ReadfromDB);
intentMap.set('ask_expert', WritetoDB);
intentMap.set('weatherIntent',Currentweather);
intentMap.set('ForecastweatherIntent',Forecastweather);
agent.handleRequest(intentMap);
  
});

async function callVisionApi(agent, bucketName, fileName1){
  const vision = require('@google-cloud/vision');
  const client = new vision.ImageAnnotatorClient();
  const [result] = await client.labelDetection(`gs://${bucketName}/${fileName1}`);
  const labels = result.labelAnnotations;
  console.log('Labels:');
  labels.forEach(label => console.log(label.description));
   
  return labels;
}
