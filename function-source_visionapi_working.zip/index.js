'use strict';
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
//const {WebhookClient} = require('dialogflow-fulfillment-improved');
const {google} = require('googleapis');
const vision = require('@google-cloud/vision');
const {Card, Suggestion} = require('dialogflow-fulfillment');
const axios = require('axios');

// initialise DB connection
const admin = require('firebase-admin');
admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  databaseURL: 'ws://demochatbot-wfse.firebaseio.com/',
});
process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements



  var CVFNews = axios.create({
    method: 'get',
    baseURL: 'https://newsapi.org/v2/',
    headers: {'x-api-key': 'db491fe0ec86424485e0e77a41e7e11b'}
    });
 
//providing storage details:
const bucketName = 'demochatbot-wfse.appspot.com';
//console.log("Parameters", agent.parameters);
const getNameHandler = "get_type";
const applyML = "explore_image";

process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements

 var WeatherNews = axios.create({
    method: 'get',
    baseURL: 'http://api.openweathermap.org/data/2.5/',
    headers: {'x-api-key': 'db7117cd435e1ae459f1254b80ce43ba'}
   });

const serviceAccount = {
  "type": "service_account",
  "project_id": "demochatbot-wfse",
  "private_key_id": "deb40f9581acd626efd6ec3de887408d982d9b8b",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCTsxFQXn3L3uc+\nHxPKYpxmvyNfGvL1njzzEiqHGheH8AzTQY6lZSOYNKRkpuyPDcaUNrkRT2EkEZR5\n4jefPGwmyWdiNHyh1O1eK30RMO3Byc8p5Ig2m4lEynbOgfbb/2i1nXaG2uE+TL8I\nkxGloOWzchdIiIocxhNgB6wAPC6reKMZhm6ASuWhIwXD+V9swhjCA4BQK46RKKPN\nzqmcXnoA88VlW68red6rT4bUreJEnplIj6YoNg2MYeKlf6SMNCC2VEGXApGsYMk1\nG9kTuBGhY4dysnftOfLupYEPcIaHPTXUSheyXQr1vZHpUzlBxj53ryWsjK1yJ+h8\nE+7PM5XZAgMBAAECggEAFVxzkkJoQoEAGV2YmM+pkQ6ZyK/MGGEvWB72JEijbeyg\n3jjVWZmxYS+pNZ69XcnUliun7myi6aWFP292iJgjiCSJcuGRGOgDqyKdBEx68ROv\n2341g7hQ97BUfcoRcCtAneuicHSILmDJIYNWV7RXzvEe6ZrzEUrwaGto9ou9sDIa\nXBOp2f9uZsTKifWIZJRmQrQkjRoPuhX9GIGGb5lwfQm44NW0ESPCFwVgaKD+D1ts\n8Ht7CBXu6xfI1jx0syzZN7E51GsE0AFs7vYqxaecdzFsi3njS9vI3gYFAgEu7iS4\nW2DMuOXJcJXxlV9QcJZrqM7Kqdb/GDGdO7OALGHkpQKBgQDNu4eTEBSGmUpRVLwz\n7FPVMyVGdnaMqboWbG+gQ/hFGiGyYlJmQAB5/p1+SjtfRMGmnE+TwK6nRx5/pWt1\natekUU75qFt/kpawokThpjqTYhUvfwC2HISdm3i+K2tPP4cGfXMxbR4r145jBR5A\nIG48R4bbNWioNcqo6LWP/WascwKBgQC3yZlAWl0OJsHv3GqP/79imPxMTxbpGxb1\nEDzPB5Li2DGt5KvmRPEOBttWIy5ir/LMl7rprXcPGApM+CzhiyP9lPezCpob8wi9\njUqJPGVDSsB2qfBu3AzHGdHiX54ENNLmYqWrHrneyvD6GS7rUoNMGLOQOwKKRJCZ\nTxaQ4RqNgwKBgGWqYEraTWpeYg1i9EYsaRkYVzlE3TyRuzXNjDQEorFzQmemktWY\nlyOyIR4BjOl9Tr0IzYJUW3qqeHXXxwyVKc83pvFUszKNvA25gpSH0rZ2Z8W62x0j\nZp2D8Nz5E+RrnkwkvkIUjC5aLTDdnJ9P52m+ZvP4pqlJO8bQiLiJHq3lAoGAR1ea\nhcCOHtAsuE93ji5YvI1mYrjQy+wYHUkQUc0+14/UuQvrLpfUev1uZyGBAA4M0h6U\nD+GmNdW/KeGsimDYt7b78CRNbkwJOIuAQ4WOSXDbBTUyf9Yrn54GOzmivT9EHups\nJODohfOBV5QvAmolTYTJL1O4yLOU7e4ldFftVsECgYBvD9vq53y2brJjRh+MdiKO\nXXG58BqcFWi46/DRCZtrZ2mJ1Ab76tj2Cxeyp+HkT3tjl1QchlcqE761rNtM1abf\nBF6la9o/gq+BMfFZykT59oElkn7GcG80Mk1EDS+sEzL/t2ewtirGfm/JzrxFZBAQ\n1YjV2tePpQwJLVZ7fn6L/Q==\n-----END PRIVATE KEY-----\n",
  "client_email": "demochatbot-wfse@appspot.gserviceaccount.com",
  "client_id": "103349211901171986296",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/demochatbot-wfse%40appspot.gserviceaccount.com"
};


exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request,response) =>{
  const agent = new WebhookClient({request, response});
 // const agent = new WebhookClient({request: request, response: response});
console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
  
function Currentweather(agent){
    response.setHeader('Content-Type','application/json');
    console.log('weather function', JSON.stringify(request.body.queryResult.parameters));
    const loc = agent.parameters.geocity;
  //  agent.add(`Below shown is temperature in Kelvin for Location #:${loc}`);
    return WeatherNews.get('/weather?q='+	encodeURIComponent(loc)  +'&units=metric')
        .then(function(response){
     console.log("Complete Weather Statistics :", JSON.stringify(response.data));
     var Currtemp = JSON.stringify(response.data.main.temp);
     var Mintemp = JSON.stringify(response.data.main.temp_min);
     var Maxtemp = JSON.stringify(response.data.main.temp_max);
     var pressure = JSON.stringify(response.data.main.pressure);
     var humidity = JSON.stringify(response.data.main.humidity);
     var Overcast = JSON.stringify(response.data.weather[0].description);
     var windSpeed = JSON.stringify(response.data.wind.speed);
     var sunrise = new Date(response.data.sys.sunrise*1000).toLocaleTimeString("en-US").slice(0,4);
     var sunset = new Date(response.data.sys.sunset*1000).toLocaleTimeString("en-US").slice(0,4); 
     
     console.log("Temperature is :", Currtemp );
  //   agent.add('The temperature for location  ' + loc + ' is: ' + Currtemp + '\nPressure is :'+ pressure + '\nHumidity is :' + humidity + '\nWind Speed is :' + windSpeed + '\nSituation is' + weatherMainDescription + 'with' + weatherDescription );
      agent.add(`\Below are the weather details for Location #:${loc}`);
      agent.add(`Current temperature    #:${Currtemp} degree Celsius`);
      agent.add(`Minimum temperature    #:${Mintemp} degree Celsius`);
      agent.add(`Maximum temperature    #:${Maxtemp} degree Celsius`);
      agent.add(`Pressure  #:${pressure}`);
      agent.add(`Overcast  #:${Overcast}`);
      agent.add(`windSpeed  #:${windSpeed}`);
      //agent.add(`SunRise time is #:${sunrise}`);
      //agent.add(`Sunset time  is #:${sunset}`);
     
   //  return agent.add('The temperature for location  ' + loc + ' is: ' + JSON.stringify(response.data) );
      })
        .catch(function(error){
            console.log(error);
        });
  }
 
//Forecast Function
    function Forecastweather(agent) {
    response.setHeader('Content-Type','application/json');
    const loc = agent.parameters.ForecastLocation;
    agent.add(`Below shown is Forecast for next 5 days in ${loc} at 12 p.m daily.`);
    return WeatherNews.get('/forecast?q='+	encodeURIComponent(loc)  +'&units=metric')
        .then(function(response){
     console.log("Weather forecast for next 5 days is :", JSON.stringify(response.data));
     
     var i = 0;
     for (i in JSON.stringify(response.data.list[i])) {
     
     //  if (i % 7 == 0) {
         //*********************************************
         var dt_text = JSON.stringify(response.data.list[i].dt_txt);
       	 var mySplitResult;
         mySplitResult = dt_text.split(" ");
         const midtime = String(mySplitResult[1]);
         
         var fixtime = "12:00:00\"";
         const time = String(fixtime);
        // agent.add(`*************date split result is #${mySplitResult[1]}`);
      //   agent.add(`******date split result is #${midtime}`);
       //  agent.add(`******Fix timeis #${time}`);
        //*********************************************
         if(midtime === time ){
           //=========================================
     	   var Currtemp = JSON.stringify(response.data.list[i].main.temp);
     	   var Mintemp = JSON.stringify(response.data.list[i].main.temp_min);
     	   var Maxtemp = JSON.stringify(response.data.list[i].main.temp_max);
     	   var pressure = JSON.stringify(response.data.list[i].main.pressure);
     	   var humidity = JSON.stringify(response.data.list[i].main.humidity);
     	   var Overcast = JSON.stringify(response.data.list[i].weather[0].description);
     	   var windSpeed = JSON.stringify(response.data.list[i].wind.speed);
     	   // var dt_text = JSON.stringify(response.data.list[i].dt_txt);
           agent.add(`\n###########################`);
      	   agent.add(`Forecast for Date   #:${dt_text}:`);
           agent.add(`#############################`);
      	   agent.add(`Current temperature    #:${Currtemp} degree Celsius`);
      	   agent.add(`Minimum temperature    #:${Mintemp} degree Celsius`);
      	   agent.add(`Maximum temperature    #:${Maxtemp} degree Celsius`);
      	   agent.add(`Overcast     #:${Overcast}`);
      	   agent.add(`Humidity    #:${humidity}`);
      	   agent.add(`Pressure    #:${pressure}`);
      	   agent.add(`windSpeed    #:${windSpeed}`);
           //===========================================
          }
       //}
    }
      
     // return agent.add('The weather forecast for next 5 days for location  ' + loc + ' is: ' + JSON.stringify(response.data));
        })
        .catch(function(error){
            console.log(error);
        });
  }
//==================================

  
 
  
function vegetation_schedule(agent)
  {
    let type = agent.parameters.type;

   agent.add(`fulfillment:you selected type: ${type}`);
      if(type.toLowerCase() == "herbs"){
 agent.add(`you selected ${type}. You can grow below herbs based on the schedule. Basil - May to October, Corriander - June to September, Parsley - May to December, Dill - June to October.Do you wish to know anything else?`);
 }
 else if(type.toLowerCase() == "salads"){
 agent.add(`you selected ${type}.You can grow below salads based on the schedule. Celery - July to November, Courgettes from July to September, Cucumbers from May to September, Lettuce from June to September.Do you wish to know anything else?`);
 }
 else if(type.toLowerCase() == "fruits"){
 agent.add(`you selected ${type}. You can grow below Fruits based on the schedule. Apples in October, blackberries in August, strawberries from June to October, Raspberries from July to October.Do you wish to know anything else?`);
 }
 else if(type.toLowerCase() == "vegetables"){
 agent.add(`you selected ${type}. You can grow below vegetables based on the schedule. Asparagus from May and June, Aubergines From May to August, Beetroot from August to Feb, Broad beans from June to August, Brocolli from June till November.Do you wish to know anything else ?`);
 }
 else{
 agent.add("Sorry , i dont Understand this ");
 }  
}
 
function visionAPIlabel(agent){
  var filename1 = agent.parameters.filename;
  console.log("filename is: ", filename1);
  console.log("bucketName is: ", bucketName);

    // call vision API to detect text
    return callVisionApi(agent, bucketName, filename1).then(result => {
       console.log(`#####Main functoin result is :`);
      agent.add(`####### Labels :######`);
      result.forEach(result22 =>
                     //console.log(result22.description)
                     agent.add(`${result22.description}`));
     //agent.add(`Inside visionApi Function : bucket name  #######:  ${bucketName}`);
    // agent.add(`Inside visionApi Function : filename  is #######:  ${filename1}`);
        }).catch((error)=> {
            agent.add(`error occurred at apply ml function`  + error);
        });
}
  
function news(agent) {
    response.setHeader('Content-Type','application/json');
    console.log('news function', JSON.stringify(request.body.queryResult.parameters));
    const word = agent.parameters.search;
    agent.add(`search word name #:${word}`);
    return CVFNews.get('top-headlines?q='+encodeURIComponent(word)+'&limit=1&tags=news')
        .then(function(response){
            const {title, source} = response.data.articles[0];
            //agent.add(`search word name #:${response.data.articles[0]}`);
            console.log('response', response.data);
            console.log('response', response.data.articles[0]);
            return agent.add('The last article about ' + word + ' was: ' + title + ' and was published by ' + source.name);
        })
        .catch(function(error){
            console.log(error);
        });
  }

 
 
function ReadfromDB(agent){  
const DBName = agent.parameters.DBName;
return admin.database().ref('vegetables').once('value').then((snapshot) => {
  var details = snapshot.child(DBName).val();
  if (snapshot.hasChild(`${DBName}`)){
   // agent.add(`${DBName} already exists in database.`);
    agent.add(`Below are the details:`);
        var time_to_grow = details.grow_time;
    var ph_val = details.ph_value;
    var ph_season = details.growing_season;
    agent.add(`***************************************`);
    agent.add(`Plant name #:${DBName}`);
    agent.add(`Time for growth for ${DBName} #:${time_to_grow}`);
    agent.add(`Soil ph value for ${DBName} #:${ph_val}`);
    agent.add(`Growing season for ${DBName} #:${ph_season}`);
    agent.add(`***************************************`);
  }
  else{
    agent.add(`I do not have information about this`);
    agent.add(`**Expert **Please provide information about ## ${DBName}:`);
  }
});
}
 
 
function WritetoDB(agent){  
  var DBName = request.body.queryResult.parameters.DBName;
  var grow_time = agent.parameters.grow_time11;
  var growing_season = agent.parameters.growing_season11;
  var ph_value = agent.parameters.ph_value11;
 

  agent.add(`Thanks Expert for the details, below data has been updated in Database:`);
  // agent.add(`***************************************`);
 // agent.add(`**plant name #:${DBName}:`);
 // agent.add(`Time for growth for ${DBName} #:${grow_time}:`);
 // agent.add(`Growing season for ${DBName} #:${growing_season}:`);
 // agent.add(`Soil ph value for ${DBName} :${ph_value}:`);
 // agent.add(`***************************************`);
    agent.add(`***************************************`);
    agent.add(`Plant name #:${DBName}`);
    agent.add(`Time for growth for ${DBName} #:${grow_time}`);
    agent.add(`Soil ph value for ${DBName} #:${ph_value}`);
    agent.add(`Growing season for ${DBName} #:${growing_season}`);
    agent.add(`***************************************`);
 
 return admin.database().ref('vegetables').child(`${DBName}`).set({
     grow_time: `${grow_time}`,
     growing_season: `${growing_season}`,
ph_value : `${ph_value}`,
   
});
 
}

 
   
let intentMap = new Map();
intentMap.set('get_type', vegetation_schedule);
intentMap.set('Image_label_int', visionAPIlabel);
intentMap.set('newsIntent', news);
intentMap.set('DBName_intent', ReadfromDB);
intentMap.set('ask_expert', WritetoDB);
intentMap.set('weatherIntent',Currentweather);
intentMap.set('ForecastweatherIntent',Forecastweather);
agent.handleRequest(intentMap);
  
});

async function callVisionApi(agent, bucketName, fileName1){
  const vision = require('@google-cloud/vision');
  const client = new vision.ImageAnnotatorClient();
  const [result] = await client.labelDetection(`gs://${bucketName}/${fileName1}`);
  const labels = result.labelAnnotations;
  console.log('Labels:');
  labels.forEach(label => console.log(label.description));
   
  return labels;
}
